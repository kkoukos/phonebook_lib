﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using NuGet.Frameworks;
using NUnit.Framework;
using phonebook_lib;

namespace unit_test
{
    internal class update_unit_tests
    {
        [Test]

      
        [TestCase ("Foo Bar",0,"random")]       //test for update function -> works correctly 
        [TestCase("Test Person",1, "6989743878")]
        [TestCase("Person Person", 2, "random")]
        public void update_listing_test_equals_test(string name, int type , string phone)
        {
            Random rnd = new Random();
            
            //Asign
            if (phone == "random")
            {
                phone = "";
                for (int i = 0; i < 10; i++)
                {
                    phone += rnd.Next(0, 9).ToString();
                }
            }
           
            List <listing> test_list = new List<listing>();
            listing test_listing = new listing(name, type, phone);
            

            //Act
            ListingProcessor.create(name, type, phone);
           

            int test_result = ListingProcessor.update(name, type, phone,"Updated Name",0,"1111111111");
            ListingProcessor.load_data();
            foreach (var item in ListingProcessor.Get_List())
            {

                test_list.Add(item);

            }
            //Assert

            Assert.AreEqual(test_result, 0);
           
            CollectionAssert.DoesNotContain(test_list,test_listing );




            Assert.Pass();
        }

        [TestCase("FooBar", 0, "random")] //test for wrong user input -> search data
        [TestCase("Test Person", 1, "6989743a78")]
        [TestCase("Person Person", 3, "random")]

        [TestCase("", 3, "random")] //test for blank input | type int cant be blank
        [TestCase("Person Person", 2, "")]

        [TestCase(null, 3, null)] //test for null input | type int cant be null
        [TestCase(null, 2, null)]



        public void not_update_listing_test_equals_test_because_wrong_starting_input(string name, int type, string phone)
        {
            Random rnd = new Random();

            //Asign
            if (phone == "random")
            {
                phone = "";
                for (int i = 0; i < 10; i++)
                {
                    phone += rnd.Next(0, 9).ToString();
                }
            }

            List<listing> test_list = new List<listing>();
            listing test_listing = new listing(name, type, phone);


            //Act
            int test_result2 = ListingProcessor.create(name, type, phone);


            int test_result = ListingProcessor.update(name, type, phone,"Updated Name", 0, "1111111111");
            ListingProcessor.load_data();
            foreach (var item in ListingProcessor.Get_List())
            {

                test_list.Add(item);

            }
            //Assert

           
            Assert.AreEqual(test_result, 4);
           
            Assert.That(test_result2, Is.Not.EqualTo(0));





            Assert.Pass();
        }

        [TestCase("Foo Barr", 0, "random", "TestWrongName", 0, "random",1)] //test for wrong user input -> update data
        [TestCase("Test Personn", 1, "6989743878", "Test Person", 3, "random",2)]
        [TestCase("Person Bar", 2, "random", "Person Bar", 0, "wrong number",3)]

        [TestCase("Foo Barr", 0, "random", "", 0, "random", 1)] //test for blank input | type int cant be blank
        [TestCase("Person Bar", 2, "random", "Person Bar", 0, "", 3)]

        [TestCase("Foo Barr", 0, "random", null, 0, null, 1)]//test for null input | type int cant be null
        [TestCase("Person Bar", 2, "random", null, 0, null, 3)]
        public void not_update_listing_test_equals_test_because_wrong_delete_input(string name, int type, string phone,string name_n, int type_n, string phone_n,int index)
        {
            Random rnd = new Random();

            //Asign
            if (phone == "random")
            {
                phone = "";
                for (int i = 0; i < 10; i++)
                {
                    phone += rnd.Next(0, 9).ToString();
                }
            }

            List<listing> test_list = new List<listing>();
           


            //Act
            int test_result2= ListingProcessor.create(name, type, phone);


            int test_result = ListingProcessor.update(name, type, phone, name_n  , type_n, phone_n);
            ListingProcessor.load_data();
            foreach (var item in ListingProcessor.Get_List())
            {

                test_list.Add(item);

            }
            //Assert

            if(test_result == index)//for wrong input 
            {
                Assert.AreEqual(test_result, index);
            }
            else if(test_result == -2)//for null input 
            {
                Assert.AreEqual(test_result, -2);

            }
            else//for any other exceptions
            {
                Assert.AreEqual(test_result, index);
            }
          

            Assert.That(test_result2, Is.EqualTo(0));
            CollectionAssert.IsNotEmpty(test_list);

          



            Assert.Pass();
        }


    }
}
