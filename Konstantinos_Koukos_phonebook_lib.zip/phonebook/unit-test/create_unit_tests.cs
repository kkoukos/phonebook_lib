﻿using phonebook_lib;

namespace unit_test
{
    internal class create_unit_tests
    {
        [Test]


        [TestCase("Foo Bar", 0, "random", 0)]   //test for create function -> works correctly 
        [TestCase("Test Person", 1, "6989743878", 1)]
        [TestCase("Person Person", 2, "random", 2)]
        public void create_listing_test_equals_test(string name, int type, string phone, int index)
        {
            Random rnd = new Random();

            //Asign
            if (phone == "random")
            {
                phone = "";
                for (int i = 0; i < 10; i++)
                {
                    phone += rnd.Next(0, 9).ToString();
                }
            }

            List<listing> test_list = new List<listing>();
            listing test_listing = new listing(name, type, phone);


            //Act
            int test_result = ListingProcessor.create(name, type, phone);
            ListingProcessor.load_data();
            foreach (var item in ListingProcessor.Get_List())
            {

                test_list.Add(item);

            }
            //Assert

            Assert.AreEqual(test_result, 0);
            Assert.AreEqual(index + 1, test_list.Count);



            Assert.AreEqual(test_listing.name, test_list[index].name);

            Assert.AreEqual(test_listing.type, test_list[index].type);
            Assert.AreEqual(test_listing.number, test_list[index].number);

            Assert.Pass();

        }

        [TestCase("FooBar", 3, "random", 0)] //test for incorrect input
        [TestCase("Test Person", 4, "random", 1)]
        [TestCase("Person Person", 2, "wrong number input", 2)]

        [TestCase("", 3, "random", 0)] //test for blank input | type int cant be blank
        [TestCase("Person Person", 2, "", 2)]

        [TestCase(null, 3, null, -3)] //test for null input | type int cant be null
        [TestCase(null, 2, null, -3)]
        public void not_create_listing_test_equals_test(string name, int type, string phone, int index)//index contains which int should be returned by the create method
        {
            Random rnd = new Random();

            //Asign
            if (phone == "random")
            {
                phone = "";
                for (int i = 0; i < 10; i++)
                {
                    phone += rnd.Next(0, 9).ToString();
                }
            }

            List<listing> test_list = new List<listing>();



            //Act
            int test_result = ListingProcessor.create(name, type, phone);
            ListingProcessor.load_data();
            foreach (var item in ListingProcessor.Get_List())
            {

                test_list.Add(item);

            }
            //Assert

            Assert.AreEqual(test_result, index + 1);

            Assert.That(test_list.Count, Is.EqualTo(3)); //because it deserializes the previous list from test above that contains 3 listings





            Assert.Pass();

        }



    }
}
