using phonebook_lib;
using System.Data;
using System.Linq.Expressions;

namespace phonebook_UI;

public partial class form_back : Form
{
    static List<listing> list = new List<listing>(); 
    DataTable dt = new DataTable();
    bool temp = false;
    public form_back()
    {


        
        dt.Columns.Add("Name", typeof(string));
        dt.Columns.Add("Type");
        dt.Columns.Add("Phone", typeof(string));



      




        InitializeComponent();
    }


    public void selected()
    {

    }

    public void refresh_data()
    {
        dt.Clear();
        list.Clear();
        ListingProcessor.load_data();
        list = ListingProcessor.Get_List();

        foreach (var item in list)
        {
            var row = dt.NewRow();
            row[0] = item.name;
            row[1] = item.type;
            row[2] = item.number;
            dt.Rows.Add(row);

        }

        grid1.DataSource = dt;

    }

    private void addb_Click(object sender, EventArgs e)
    {
        if (!temp )
        {
            temp = true;
            grid1.Visible = false;
            panel2.Visible = true;
            add_but.Visible = true;
            edit_but.Visible = false;
            name_box.Text = "Name";
            phone_box.Text = "Phone Number";

          
            
            //  ListingProcessor.load_data();
            //   list = ListingProcessor.Get_List();
            refresh_data();
        }
       


    }

    private void editb_Click(object sender, EventArgs e)
    {
        if (!temp && list.Count>0)
        {
            temp = true;
            grid1.Visible = false;
            panel2.Visible = true;
            add_but.Visible = false;
            edit_but.Visible = true;
            int i = grid1.SelectedCells[0].RowIndex;

            string name = grid1.Rows[i].Cells[0].Value.ToString();
            string phone = grid1.Rows[i].Cells[2].Value.ToString();
            int type = Int16.Parse(grid1.Rows[i].Cells[1].Value.ToString());
            testl.Text = name;
            label1.Text = phone;

            name_box.Text = name;
            phone_box.Text = phone;
            type_box.SelectedIndex = type;
            ListingProcessor.update(name, type,phone, name_box.Text,type_box.SelectedIndex,phone_box.Text);
  
        }
        
    }

    private void delb_Click(object sender, EventArgs e)
    {
        if( list.Count > 0)
        {
            int i = grid1.SelectedCells[0].RowIndex;

            testl.Text = ListingProcessor.delete(grid1.Rows[i].Cells[0].Value.ToString(), Int16.Parse(grid1.Rows[i].Cells[1].Value.ToString()), grid1.Rows[i].Cells[2].Value.ToString()).ToString();
            refresh_data();
        }
        
    }

    

    private void pictureBox1_Click(object sender, EventArgs e)
    {
        grid1.Visible = true;
        panel2.Visible = false;
        temp = false;

    }

    private void add_but_Click(object sender, EventArgs e)
    {

        if (type_box.SelectedIndex>-1)
        {
           int i =  ListingProcessor.create(name_box.Text, type_box.SelectedIndex, phone_box.Text);
           error_label.Text = i.ToString();
           
            if (i == 0)
            {
                refresh_data();
                grid1.Visible = true;
                panel2.Visible = false;
                temp = false;

            }
        }
        else
        {
            error_label.Text = "No type picked";
        }
        
    }

    private void refresh_but_Click(object sender, EventArgs e)
    {
        refresh_data();
    }

    private void edit_but_Click(object sender, EventArgs e)
    {
        refresh_data();
        int i = grid1.SelectedCells[0].RowIndex;
        string name = grid1.Rows[i].Cells[0].Value.ToString();
        string phone = grid1.Rows[i].Cells[2].Value.ToString();
        int type = Int16.Parse(grid1.Rows[i].Cells[1].Value.ToString());
        
        i = ListingProcessor.update(name, type, phone, name_box.Text, type_box.SelectedIndex, phone_box.Text);
        error_label.Text = i.ToString();
        if (i == 0)
        {
            refresh_data();
            grid1.Visible = true;
            panel2.Visible = false;
            temp = false;

        }
      

    }

    private void order_name_Click(object sender, EventArgs e)
    {
      
        dt.Clear();
        list.Clear();
        label1.Text = "order by name";
        
        list = ListingProcessor.iterate_alphabetical();
        testl.Text = list.Count.ToString();
        foreach (var item in list)
        {
            var row = dt.NewRow();
            row[0] = item.name;
            row[1] = item.type;
            row[2] = item.number;
            dt.Rows.Add(row);

        }

        grid1.DataSource = dt;
    }

    private void order_fname_Click(object sender, EventArgs e)
    {
        dt.Clear();
        list.Clear();
        label1.Text = "order by fisrt name";

        list = ListingProcessor.iterate_alphabetical_first();
        testl.Text = list.Count.ToString();
        foreach (var item in list)
        {
            var row = dt.NewRow();
            row[0] = item.fullname;
            row[1] = item.type;
            row[2] = item.number;
            dt.Rows.Add(row);

        }

        grid1.DataSource = dt;
    }

    private void order_lname_Click(object sender, EventArgs e)
    {
        dt.Clear();
        list.Clear();
        label1.Text = "order by last name";

        list = ListingProcessor.iterate_alphabetical_last();
        testl.Text = list.Count.ToString();
        foreach (var item in list)
        {
            var row = dt.NewRow();
            row[0] = item.fullname;
            row[1] = item.type;
            row[2] = item.number;
            dt.Rows.Add(row);

        }

        grid1.DataSource = dt;
    }
}