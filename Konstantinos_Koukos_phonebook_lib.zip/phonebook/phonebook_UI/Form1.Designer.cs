﻿namespace phonebook_UI
{
    partial class form_back
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.order_lname = new System.Windows.Forms.Button();
            this.order_fname = new System.Windows.Forms.Button();
            this.order_name = new System.Windows.Forms.Button();
            this.refresh_but = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.testl = new System.Windows.Forms.Label();
            this.delb = new System.Windows.Forms.Button();
            this.editb = new System.Windows.Forms.Button();
            this.addb = new System.Windows.Forms.Button();
            this.listingProcessorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.grid1 = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.error_label = new System.Windows.Forms.Label();
            this.edit_but = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.add_but = new System.Windows.Forms.Button();
            this.type_box = new System.Windows.Forms.ComboBox();
            this.phone_box = new System.Windows.Forms.TextBox();
            this.name_box = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.listingProcessorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Controls.Add(this.order_lname);
            this.panel1.Controls.Add(this.order_fname);
            this.panel1.Controls.Add(this.order_name);
            this.panel1.Controls.Add(this.refresh_but);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.testl);
            this.panel1.Controls.Add(this.delb);
            this.panel1.Controls.Add(this.editb);
            this.panel1.Controls.Add(this.addb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 70);
            this.panel1.TabIndex = 0;
            // 
            // order_lname
            // 
            this.order_lname.BackColor = System.Drawing.Color.White;
            this.order_lname.Location = new System.Drawing.Point(234, 10);
            this.order_lname.Name = "order_lname";
            this.order_lname.Size = new System.Drawing.Size(105, 48);
            this.order_lname.TabIndex = 8;
            this.order_lname.Text = "ORDER BY LAST NAME";
            this.order_lname.UseVisualStyleBackColor = false;
            this.order_lname.Click += new System.EventHandler(this.order_lname_Click);
            // 
            // order_fname
            // 
            this.order_fname.BackColor = System.Drawing.Color.White;
            this.order_fname.Location = new System.Drawing.Point(123, 10);
            this.order_fname.Name = "order_fname";
            this.order_fname.Size = new System.Drawing.Size(105, 48);
            this.order_fname.TabIndex = 7;
            this.order_fname.Text = "ORDER BY FIRST NAME";
            this.order_fname.UseVisualStyleBackColor = false;
            this.order_fname.Click += new System.EventHandler(this.order_fname_Click);
            // 
            // order_name
            // 
            this.order_name.BackColor = System.Drawing.Color.White;
            this.order_name.Location = new System.Drawing.Point(12, 10);
            this.order_name.Name = "order_name";
            this.order_name.Size = new System.Drawing.Size(105, 48);
            this.order_name.TabIndex = 6;
            this.order_name.Text = "ORDER BY NAME";
            this.order_name.UseVisualStyleBackColor = false;
            this.order_name.Click += new System.EventHandler(this.order_name_Click);
            // 
            // refresh_but
            // 
            this.refresh_but.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.refresh_but.BackColor = System.Drawing.Color.White;
            this.refresh_but.BackgroundImage = global::phonebook_UI.Properties.Resources.index5;
            this.refresh_but.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.refresh_but.Location = new System.Drawing.Point(594, 14);
            this.refresh_but.Name = "refresh_but";
            this.refresh_but.Size = new System.Drawing.Size(40, 40);
            this.refresh_but.TabIndex = 5;
            this.refresh_but.UseVisualStyleBackColor = false;
            this.refresh_but.Click += new System.EventHandler(this.refresh_but_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(385, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "debugging labels";
            // 
            // testl
            // 
            this.testl.AutoSize = true;
            this.testl.Location = new System.Drawing.Point(385, 14);
            this.testl.Name = "testl";
            this.testl.Size = new System.Drawing.Size(139, 15);
            this.testl.TabIndex = 3;
            this.testl.Text = "press refresh to load data";
            // 
            // delb
            // 
            this.delb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.delb.BackColor = System.Drawing.Color.White;
            this.delb.BackgroundImage = global::phonebook_UI.Properties.Resources.index;
            this.delb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.delb.Location = new System.Drawing.Point(732, 14);
            this.delb.Name = "delb";
            this.delb.Size = new System.Drawing.Size(40, 40);
            this.delb.TabIndex = 2;
            this.delb.UseVisualStyleBackColor = false;
            this.delb.Click += new System.EventHandler(this.delb_Click);
            // 
            // editb
            // 
            this.editb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.editb.BackColor = System.Drawing.Color.White;
            this.editb.BackgroundImage = global::phonebook_UI.Properties.Resources.index2;
            this.editb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.editb.Location = new System.Drawing.Point(686, 14);
            this.editb.Name = "editb";
            this.editb.Size = new System.Drawing.Size(40, 40);
            this.editb.TabIndex = 1;
            this.editb.UseVisualStyleBackColor = false;
            this.editb.Click += new System.EventHandler(this.editb_Click);
            // 
            // addb
            // 
            this.addb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.addb.BackColor = System.Drawing.Color.White;
            this.addb.BackgroundImage = global::phonebook_UI.Properties.Resources.index3;
            this.addb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.addb.Location = new System.Drawing.Point(640, 14);
            this.addb.Name = "addb";
            this.addb.Size = new System.Drawing.Size(40, 40);
            this.addb.TabIndex = 0;
            this.addb.UseVisualStyleBackColor = false;
            this.addb.Click += new System.EventHandler(this.addb_Click);
            // 
            // listingProcessorBindingSource
            // 
            this.listingProcessorBindingSource.DataSource = typeof(phonebook_lib.ListingProcessor);
            // 
            // grid1
            // 
            this.grid1.AllowUserToAddRows = false;
            this.grid1.AllowUserToDeleteRows = false;
            this.grid1.AllowUserToResizeColumns = false;
            this.grid1.AllowUserToResizeRows = false;
            this.grid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid1.Location = new System.Drawing.Point(0, 70);
            this.grid1.MultiSelect = false;
            this.grid1.Name = "grid1";
            this.grid1.ReadOnly = true;
            this.grid1.RowTemplate.Height = 25;
            this.grid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid1.Size = new System.Drawing.Size(800, 380);
            this.grid1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel2.Controls.Add(this.error_label);
            this.panel2.Controls.Add(this.edit_but);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.add_but);
            this.panel2.Controls.Add(this.type_box);
            this.panel2.Controls.Add(this.phone_box);
            this.panel2.Controls.Add(this.name_box);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 70);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 380);
            this.panel2.TabIndex = 2;
            this.panel2.Visible = false;
            // 
            // error_label
            // 
            this.error_label.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.error_label.AutoSize = true;
            this.error_label.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.error_label.ForeColor = System.Drawing.Color.White;
            this.error_label.Location = new System.Drawing.Point(385, 330);
            this.error_label.Name = "error_label";
            this.error_label.Size = new System.Drawing.Size(0, 30);
            this.error_label.TabIndex = 7;
            this.error_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // edit_but
            // 
            this.edit_but.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.edit_but.BackColor = System.Drawing.Color.White;
            this.edit_but.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.edit_but.Location = new System.Drawing.Point(356, 262);
            this.edit_but.Name = "edit_but";
            this.edit_but.Size = new System.Drawing.Size(103, 41);
            this.edit_but.TabIndex = 6;
            this.edit_but.Text = "EDIT";
            this.edit_but.UseVisualStyleBackColor = false;
            this.edit_but.Click += new System.EventHandler(this.edit_but_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackgroundImage = global::phonebook_UI.Properties.Resources.index4;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(688, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 37);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // add_but
            // 
            this.add_but.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.add_but.BackColor = System.Drawing.Color.White;
            this.add_but.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.add_but.Location = new System.Drawing.Point(356, 262);
            this.add_but.Name = "add_but";
            this.add_but.Size = new System.Drawing.Size(103, 41);
            this.add_but.TabIndex = 4;
            this.add_but.Text = "ADD";
            this.add_but.UseVisualStyleBackColor = false;
            this.add_but.Click += new System.EventHandler(this.add_but_Click);
            // 
            // type_box
            // 
            this.type_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.type_box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.type_box.FormattingEnabled = true;
            this.type_box.Items.AddRange(new object[] {
            "Work",
            "Cellphone",
            "Home"});
            this.type_box.Location = new System.Drawing.Point(254, 200);
            this.type_box.Name = "type_box";
            this.type_box.Size = new System.Drawing.Size(299, 23);
            this.type_box.TabIndex = 3;
            // 
            // phone_box
            // 
            this.phone_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.phone_box.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.phone_box.Location = new System.Drawing.Point(254, 136);
            this.phone_box.MaxLength = 10;
            this.phone_box.Name = "phone_box";
            this.phone_box.Size = new System.Drawing.Size(299, 35);
            this.phone_box.TabIndex = 2;
            // 
            // name_box
            // 
            this.name_box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.name_box.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.name_box.Location = new System.Drawing.Point(254, 78);
            this.name_box.Name = "name_box";
            this.name_box.Size = new System.Drawing.Size(299, 35);
            this.name_box.TabIndex = 0;
            // 
            // form_back
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.grid1);
            this.Controls.Add(this.panel1);
            this.Name = "form_back";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.listingProcessorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Button addb;
        private Button delb;
        private Button editb;
        private Label testl;
        private BindingSource listingProcessorBindingSource;
        private DataGridView grid1;
        private Panel panel2;
        private TextBox phone_box;
        private TextBox name_box;
        private ComboBox type_box;
        private Button add_but;
        private PictureBox pictureBox1;
        private Button edit_but;
        private Label error_label;
        private Label label1;
        private Button refresh_but;
        private Button order_lname;
        private Button order_fname;
        private Button order_name;
    }
}