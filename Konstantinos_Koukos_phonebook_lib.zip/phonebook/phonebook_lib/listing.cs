﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace phonebook_lib;
[Serializable]
public class listing
{
    public string name;//Name is a string containing a-z, A-Z , in the format firstname lastname
    public int type; //type is 0 1 2 -> Work Cellphone Home
    public string number;//An unsigned int var can store numbers up to 4_294_967_295, a long var would be too big, so we use a string format 
    public string fullname; // this is null we only use it when we want to search by last or first name
  



    public listing(string name_t,int type_t,string number_t) //constructor to auto initialize each listing 
    {
        name = name_t;
        type = type_t;  
        number = number_t;
      
       
    }



}
