﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace phonebook_lib;

public class ListingProcessor
{
   

    static List<listing> list = new List<listing>(); //a list of listing class obj that store all of the needed data 
    
    public static int load_data() // essential for UI code -> to be run on UI start 
    {
        deserialize();        
        return 0;
    }

    public static List<listing> Get_List() // sends the list to the UI ->  the UI needs to access a listing class to show data ->  the class needs to be public
    {   
        
        return list;
    }

    private static int check_for_null_input(string name,int type,string number)
    {
        if(name==null || type==null || number == null)
        {
            return -1;
        }
        return 0;
    }

    public static int create(string name,int type,string number)//gets data from UI
    {
        lock (list) //locks refrence obj list so that it cant be accessed by multiple threads simultaneously ->all of the data is stored in this list thus  
           //no two operations should me done at the same time on the list  e.g. if the user tries to edit and delete at the same time one of the operations wont 
           //have the desired effect on the list 
        {

            if(check_for_null_input(name, type, number)==-1)
            {
                return -2;
            }

            int i = check_valid_input(name, type, number); //checks if the variables are in the correct format 
            if (!(i == 0)) //returns to UI 1-3 based on which var has a wrong value 
            {
                return i;
            }

            if (cont(name, type, number) == -1) // if a listing with the same name type and number exists -> dont add a second isntance to the list
            {
                list.Add(new listing(name, type, number));//else if the variables have correct values add them to the list
                serialize(); // serialize list and save the newly added listing 
                return 0;
            }
            else
            {
                return 4;//if listing already exists in the list inform UI
            }

        }
    }

    public static int delete(string name, int type, string number)//finds the index of a listing in the list and deletes it 
    {
        lock (list)
        {
            if (check_for_null_input(name, type, number) == -1)
            {
                return -2;
            }
            int index = cont(name, type, number); //checks if the listing exists in the list 
            if (!(index == -1))
            {
                list.RemoveAt(index); //removes the listing from the list 
                serialize();//saves the new list 
                return 0;
            }

            return -1; // if it doesnt exist 
        }
    }

    public static int update(string name_old, int type_old, string number_old, string name, int type, string number)// adds the new data given and deletes the old ones 
    {
        lock (list)
        {
           

            if (check_for_null_input(name, type, number) == -1)
            {
                return -2;
            }
            int i = check_valid_input(name, type, number);//checks if the new variables have correct values 
            if (!(i == 0))
            {
                return i;
            }
            int index = cont(name_old, type_old, number_old);//finds the index of the old listing 
            if (!(index == -1))
            {
                list.RemoveAt(index);   //removes old listing 
                list.Insert(index, new listing(name, type, number));//inserts new listing 
                serialize();//saves the new list 
                return 0;
            }

            return 4;

        }
    }


    private static int check_valid_input(string name, int type, string number)// using regular expressions it checks the values given by the user/UI
    {
        name = name.ToLower();
        var r = new Regex(@"^[a-zA-Z]+( )+[a-zA-Z]+$");
        if (!r.IsMatch(name))
        {
            return 1;
        }
        if (type<0 || type > 2)  // type ==1 -> Work ,  type == 2 -> Cellphone , type == 3 -> Home
        {
            return 2;
        }
        r = new Regex(@"^[0-9]{10}$");
        if (!r.IsMatch(number))
        {
            return 3;
        }
        return 0;//if it is correct it sends back 0 else based on the innacurate data given it sends the corresponding number to the UI
                 //so the user can correct his input 
                 

    }
    
    public static List<listing> iterate_alphabetical()//it creates a temporay list and it sorts it in an alphabetical order 
    {
        List<listing> list_temp = new List<listing>();
        deserialize();
        foreach (var item in list)//it clones the list into the temporary one
        {
            list_temp.Add(item);
        }
       

        list_temp = list_temp.OrderBy(p => p.name).ToList();// using linq it sorts the temporary list of objects based on the name of each listing  


        return list_temp;//it sends the ordered list to the UI in order for the user to see if its correctly arragned 
    }

    public static List<listing> iterate_alphabetical_first()//same as above, only this time it splits the first name and last name ,
                                                            //it saves the whole name in the fullname variable so we can iterate the whole name if needed
    {
        List<listing> list_temp = new List<listing>();
        deserialize();
     
        foreach (var item in list)

        {
            item.fullname = item.name;
            var name_temp = item.name.Split(' ');
            item.name = name_temp[0];
            list_temp.Add(item);
        }


        list_temp = list_temp.OrderBy(p => p.name).ToList();


        return list_temp;
    }

    public static List<listing> iterate_alphabetical_last()
    {
        List<listing> list_temp = new List<listing>();
        deserialize();

        foreach (var item in list)

        {
            item.fullname = item.name;
            var name_temp = item.name.Split(' ');
            item.name = name_temp[1];            
            list_temp.Add(item);
        }


        list_temp = list_temp.OrderBy(p => p.name).ToList();


        return list_temp;
    }

    public static int cont(string name, int type, string number)   //finds the index of an item in the list 
    {
        int i = 0;
        foreach (var item in list)
        {
            if(item.name == name && item.type == type && item.number == number)
            {
                return i;//if the item exists it breaks the loop and returns to the main program the index 
            }

        }
        return -1;//in case it doesnt returns to the program -1 , which cant be an index of a list
    }

    private static int deserialize() //should only be accessed by back-end thus is private 
    {


        if (File.Exists("data.bin"))//gets data from a bin file -> list of listing objects
        {
            Stream stream = new FileStream("data.bin", FileMode.Open, FileAccess.Read, FileShare.Read);
            IFormatter formatter = new BinaryFormatter();
            list = (List<listing>)formatter.Deserialize(stream);
            stream.Close();

        }

        return 0;
    }

    private static int serialize()//saves data in a list -> binary format 
    {


        IFormatter formatter = new BinaryFormatter();
        Stream stream = new FileStream("data.bin", FileMode.Create, FileAccess.Write, FileShare.None);
        formatter.Serialize(stream, list);
        stream.Close();

        return 0;
    }

}
